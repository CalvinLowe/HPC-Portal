<?php
/**
 * @file
 */
?>
<div class="menu_tree_grid row">
  <?php print drupal_render($menu_tree); ?>
</div>
